const $=s=>document.querySelector(s);
let rows=[];
async function load(){
  const params=new URLSearchParams({q:$("#q").value,city:$("#city").value});
  const r=await fetch("/api/restaurants?"+params); rows=(await r.json()).restaurants; render();
}
function render(){
  const sort=$("#sort").value;
  rows=[...rows].sort((a,b)=>sort==="name"?a.name.localeCompare(b.name):sort==="reviews"?b.reviews-a.reviews:b.rating-a.rating);
  $("#resultText").textContent=`${rows.length} places found`;
  $("#grid").innerHTML=rows.map(r=>`<article class="card">
    <div class="pic"><img src="${r.image||fallback()}" alt="${esc(r.name)}"><span>${r.featured?"✨ Featured":"🍽️ Food spot"}</span></div>
    <div class="body"><div class="top"><h3>${esc(r.name)}</h3><b>★ ${Number(r.rating).toFixed(1)}</b></div>
    <p class="muted">📍 ${esc(r.area||r.city)}, ${esc(r.city)} · ${esc(r.cuisine)}</p>
    <div class="tags">${(r.tags||[]).map(t=>`<small>${esc(t)}</small>`).join("")}</div>
    <div class="price">${esc(r.price||"Price not listed")} · ${Number(r.reviews||0).toLocaleString()} reviews</div>
    <div class="actions"><button onclick='details(${JSON.stringify(r)})'>View details</button><button class="primary" onclick="maps('${esc(r.address)}')">Directions</button></div></div></article>`).join("");
  $("#empty").style.display=rows.length?"none":"block";
}
function details(r){alert(`${r.name}\n\n${r.address}\n${r.cuisine}\n${r.price||""}\n★ ${r.rating} (${r.reviews} reviews)\n\nTags: ${(r.tags||[]).join(", ")}`)}
function maps(a){window.open("https://www.google.com/maps/search/?api=1&query="+encodeURIComponent(a),"_blank")}
function fallback(){return "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=900&q=80"}
function esc(x){return String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
async function cities(){
 const r=await fetch("/api/cities"), cs=(await r.json()).cities;
 $("#city").innerHTML='<option value="all">All cities</option>'+cs.map(c=>`<option>${esc(c)}</option>`).join("");
 $("#cityPills").innerHTML=cs.map(c=>`<button data-city="${esc(c)}">${esc(c)}</button>`).join("");
 document.querySelectorAll("#cityPills button").forEach(b=>b.onclick=()=>{$("#city").value=b.dataset.city;load();$("#discover").scrollIntoView({behavior:"smooth"})});
}
$("#go").onclick=load; $("#q").onkeydown=e=>{if(e.key==="Enter")load()}; $("#city").onchange=load; $("#sort").onchange=render;
cities().then(load);