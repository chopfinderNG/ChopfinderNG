# ChopFinder NG — Working MVP

This version upgrades the original static design into a working Node.js application.

## What works
- Public restaurant discovery page
- Search by restaurant, cuisine, area and tags
- City filters
- Sorting by rating, review count and name
- Google Maps directions
- Persistent restaurant database in `data.json`
- Admin login
- Admin statistics
- Add / edit / delete restaurants
- Featured listings
- Restaurant photos, phone, prices, tags and review counts

## Run locally

Requirements: Node.js 18+.

```bash
npm start
```

Then open:
- Public site: http://localhost:3000
- Dashboard: http://localhost:3000/admin

Default local dashboard login:
- Username: `admin`
- Password: `change-me-now`

Before publishing, change credentials:
- Linux/macOS: `ADMIN_USER=yourname ADMIN_PASS=strongpassword npm start`
- Windows PowerShell: `$env:ADMIN_USER="yourname"; $env:ADMIN_PASS="strongpassword"; npm start`

## Database

The MVP uses `data.json` so it works without installing a database server. Every dashboard change is saved to that file.

For a production deployment, replace this with PostgreSQL/Supabase and add:
- owner accounts
- email/phone verification
- image uploads
- review moderation
- live opening hours
- delivery/order links
- reservation integration
- analytics
- role-based admin permissions
- backups and audit logs

## Seed data

The included seed listings use current public directory/business information available during development. Examples include current Lagos business data and Abuja directory data. Verify every listing with the restaurant before commercial publication; ratings, prices and opening hours change.

The project deliberately separates seed data from the code so the dashboard can maintain the directory without editing HTML.
