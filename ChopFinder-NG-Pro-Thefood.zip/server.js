const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const url = require("url");

const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || "Thefood";
const ADMIN_PASS = process.env.ADMIN_PASS || "kenny234@";
const ROOT = __dirname;
const DB = path.join(ROOT, "data.json");
const PUBLIC = path.join(ROOT, "public");
const sessions = new Map();

function readDB(){ return JSON.parse(fs.readFileSync(DB,"utf8")); }
function writeDB(db){ fs.writeFileSync(DB, JSON.stringify(db,null,2)); }
function send(res,status,data,type="application/json"){
  res.writeHead(status,{"Content-Type":type,"Cache-Control":"no-store"});
  res.end(type==="application/json"?JSON.stringify(data):data);
}
function body(req){
  return new Promise((resolve,reject)=>{
    let s=""; req.on("data",c=>s+=c);
    req.on("end",()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}});
  });
}
function authed(req){
  const c=(req.headers.cookie||"").split(";").map(x=>x.trim()).find(x=>x.startsWith("cf_session="));
  return c && sessions.has(c.split("=")[1]);
}
function id(){return crypto.randomBytes(7).toString("hex");}
function clean(r){
  return {...r,id:r.id||id(),tags:Array.isArray(r.tags)?r.tags:[]};
}
function api(req,res,u){
  if(u.pathname==="/api/restaurants" && req.method==="GET"){
    const db=readDB(); const q=(u.searchParams.get("q")||"").toLowerCase();
    const city=u.searchParams.get("city")||"all";
    let rows=db.restaurants.filter(r=>{
      const hay=[r.name,r.city,r.area,r.cuisine,...(r.tags||[])].join(" ").toLowerCase();
      return (!q||hay.includes(q))&&(city==="all"||r.city===city);
    });
    return send(res,200,{restaurants:rows});
  }
  if(u.pathname==="/api/cities" && req.method==="GET"){
    return send(res,200,{cities:[...new Set(readDB().restaurants.map(r=>r.city))].sort()});
  }
  if(u.pathname==="/api/login" && req.method==="POST"){
    return body(req).then(b=>{
      if(b.username===ADMIN_USER && b.password===ADMIN_PASS){
        const token=crypto.randomBytes(24).toString("hex"); sessions.set(token,true);
        res.writeHead(200,{"Set-Cookie":`cf_session=${token}; HttpOnly; SameSite=Lax; Path=/`,"Content-Type":"application/json"});
        return res.end(JSON.stringify({ok:true}));
      }
      send(res,401,{error:"Invalid login"});
    });
  }
  if(u.pathname==="/api/logout" && req.method==="POST"){
    const c=(req.headers.cookie||"").match(/cf_session=([^;]+)/); if(c)sessions.delete(c[1]);
    return send(res,200,{ok:true});
  }
  if(u.pathname==="/api/me" && req.method==="GET") return send(res,200,{authenticated:!!authed(req)});
  if(!authed(req)) return send(res,401,{error:"Admin login required"});

  if(u.pathname==="/api/admin/restaurants" && req.method==="GET") return send(res,200,{restaurants:readDB().restaurants});
  if(u.pathname==="/api/admin/stats" && req.method==="GET"){
    const rs=readDB().restaurants;
    return send(res,200,{restaurants:rs.length,cities:new Set(rs.map(r=>r.city)).size,featured:rs.filter(r=>r.featured).length,avgRating:rs.length?(rs.reduce((a,b)=>a+(+b.rating||0),0)/rs.length).toFixed(1):"0.0"});
  }
  const m=u.pathname.match(/^\/api\/admin\/restaurants\/([^/]+)$/);
  if(m){
    const rid=m[1], db=readDB(), idx=db.restaurants.findIndex(r=>r.id===rid);
    if(req.method==="PUT"){
      if(idx<0)return send(res,404,{error:"Restaurant not found"});
      return body(req).then(b=>{db.restaurants[idx]=clean({...db.restaurants[idx],...b,id:rid});writeDB(db);send(res,200,db.restaurants[idx])});
    }
    if(req.method==="DELETE"){
      if(idx<0)return send(res,404,{error:"Restaurant not found"});
      db.restaurants.splice(idx,1);writeDB(db);return send(res,200,{ok:true});
    }
  }
  if(u.pathname==="/api/admin/restaurants" && req.method==="POST"){
    return body(req).then(b=>{const db=readDB(), r=clean(b);db.restaurants.push(r);writeDB(db);send(res,201,r)});
  }
  send(res,404,{error:"Not found"});
}
function staticFile(req,res){
  let pathname=url.parse(req.url).pathname;
  if(pathname==="/"||pathname==="/index.html")pathname="/index.html";
  if(pathname==="/admin")pathname="/admin.html";
  const file=path.normalize(path.join(PUBLIC,pathname));
  if(!file.startsWith(PUBLIC))return send(res,403,{error:"Forbidden"});
  fs.readFile(file,(e,data)=>{
    if(e)return send(res,404,{error:"Page not found"});
    const ext=path.extname(file); const types={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"application/javascript; charset=utf-8",".json":"application/json"};
    send(res,200,data,types[ext]||"application/octet-stream");
  });
}
http.createServer((req,res)=>{
  const u=url.parse(req.url,true);
  if(u.pathname.startsWith("/api/")) return api(req,res,u);
  staticFile(req,res);
}).listen(PORT,()=>console.log(`ChopFinder NG running at http://localhost:${PORT}`));
